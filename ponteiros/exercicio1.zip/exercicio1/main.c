#include <stdio.h>
#include <stdlib.h>


int concat(char *str1, char *str2, char *result){
    int resultPos = 0;

    for(int i = 0; i < 100; i ++) {
        if (str1[i] == '\0') {
            break;
        }
        result[resultPos] = str1[i];
        resultPos ++;
    }

    for(int i = 0; i < 100; i ++) {
        if(str2[i] == '\0') {
            break;
        }
        result[resultPos] = str2[i];
        resultPos ++;
    }
    result[resultPos] = '\0';
    return 0;
}

int main()
{
    char string1[10];
    char string2[10];
    char result[20];

    printf("Digite uma string!\n");
    gets(string1);

    printf("\n Digite outra string!\n");
    gets(string2);

    concat(string1, string2, result);
    printf("%s", result);


    return 0;
}
